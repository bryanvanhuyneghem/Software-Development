﻿
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace TekenProject
{

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Point start;
        
        public MainWindow()
        {
            InitializeComponent();
    
        }

        #region MouseEvents       
        private void canvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            canvas.CaptureMouse();
            start =e.GetPosition(canvas);
        }

        private void canvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            canvas.ReleaseMouseCapture();
            Point eind = e.GetPosition(canvas);
            DrawEllips(start, eind);
            DrawLine(start, eind);
        }
        private void canvas_MouseMove(object sender, MouseEventArgs e)
        {
            
        }
        #endregion

        #region Draw methods
        private void DrawLine(Point start, Point eind)
        {
            Line line = new Line();
            line.Stroke = Brushes.Blue;
            line.X1 = start.X;
            line.Y1 = start.Y;
            line.X2 = eind.X;
            line.Y2 = eind.Y;
            canvas.Children.Add(line);
        }

        private void DrawEllips(Point start, Point eind)
        {
            Shape shape = new Ellipse();
            shape.Width = Math.Abs(eind.X - start.X);
            shape.Height = Math.Abs(eind.Y - start.Y);
            shape.Stroke = Brushes.Black;
            shape.Fill = Brushes.Red;

            Canvas.SetLeft(shape, Math.Min(start.X, eind.X));
            Canvas.SetTop(shape, Math.Min(start.Y, eind.Y));
            canvas.Children.Add(shape);
        }
        #endregion

        #region Button_Click events
        private void btnStroke_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnFill_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnPencil_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnLine_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnRectangle_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnEllipse_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnUndo_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {

        }
        #endregion
    }
}
